class cArc{
  create(x,y,w,h,start,end){
    arc(x,y,w,h,start,end)
  }
}
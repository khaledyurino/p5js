let n = 7
let carc = []
let r = 300
let p0 = []
let p1 = []
let x = 0
let y = 0
let v0I = []
let v1I = []
let d = []
space = 13

function setup() {
  createCanvas(400, 400);
  stroke('yellow')
  strokeWeight(5)
  for (let i = 0; i < n; i++) {
    carc[i] = new cArc()
    p0[i] = random(0, PI * 2)
    p1[i] = random(0, PI * 2)
    v0I[i] = random(0,2*PI)
    d[i] = floor(random(1, 3))
    v1I[i] = random(0,PI/2)
  }
  mic = new p5.AudioIn();

  // start the Audio Input.
  // By default, it does not .connect() (to the computer speakers)
  mic.start();
}

function draw() {
  background(220);
  let vol = mic.getLevel();
  translate(width / 2, height / 2)

  for (let i = 0; i < n; i++) {
    v0I[i] += ((v1I[i]/100 + (vol/2)) * (-1) ** d[i]);
    push();
    rotate(v0I[i])
    carc[i].create(x, y, r + i * space, r + i * space, p0[i], p1[i])
    pop();
  }
  // console.log(vI[n-1])
  noFill()
  // console.log(int(vol*100))
}
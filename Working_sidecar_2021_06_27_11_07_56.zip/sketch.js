a = [[1,1]]
ax=0
function setup() {
  createCanvas(400, 400);
  background(0)
  // let n = 0
 // let nVer = a.length
 // size = 0
 // for(let k = 0; k < a.length;k++){
 //  if(a[k].length  > n){
 //    n = a[k].length
 //  }
 // }
}
function draw(){
  translate(-width/2,0)
  background(0);
   size=min(width,height);
  for(i=0;i<a.length;i++){
    size=min(size,min(width/(a[i].length),height/(a.length)))
  }
 for(let i = 0;i<a.length;i++){  
      for(let j = 0; j < a[i].length;j++){
     if(a[i][j]){
       // size = min(width/n,height/nVer)
       // console.log(size)
       let x = j*((width-size)/max(a[i].length-1,1))
       let y = i*((height-size))/max(a.length-1,1)
       rect((ax+x+size)%(width+size),y,size)
       }
     }
   }
  update();
  // console.log(ax)
}

function update(){
  ax++;
}
let crect = []
function setup() {
  let x = random()
  createCanvas(400, 400);
  crect[0] = new cRect()
  crect[1] = new cRect()
  crect[2] = new cRect()
  crect[3] = new cRect()
  crect[4] = new cRect()
  crect[5] = new cRect()
  crect[6] = new cRect()
  crect[7] = new cRect()
}

function draw() {
  background(220);
  line(width/2,0,width/2,height)
  line(0,height/2,width,height/2)
  line(0,0,width,height)
  line(0,height,width,0)
  
  translate(width/2,height/2)
  for(let i=0;i<=7;i++){
    if(i%2==0 && (-1)**i){
      crect[i].create(mouseX-width/2,mouseY-height/2)
    }else{
      crect[i].create(-(mouseX-width/2),mouseY-height/2)
    }
      
   rotate(PI/2) 
  }
  // crect[0].create(mouseX,mouseY)
  // crect[1].create(mouseX,height-5- mouseY)
  // crect[2].create(width-5- mouseX,mouseY)
  // crect[3].create(width-5-mouseX,height-5 -mouseY)
}
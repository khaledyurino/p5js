class cRect{
  create(x,y){
    rect(x,y,5)
  }
}
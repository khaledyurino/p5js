let controlX = 1
let posX = 0
stateX = false
stateY = true
size = 50
let posY= 0
let controlY = 0
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  rect(posX,posY,size)
  move()
  if(posX % (width-size)  + posY % (height-size)== 0){
    controlX = control(controlX,stateX)[0]
    stateX = control(controlX,stateX)[1]
    controlY = control(controlY,stateY)[0]
    stateY = control(controlY,stateY)[1]
  }
//   if(posX == width-size && posY == 0){
//     controlX = control(controlX,stateX)[0]
//     stateX = control(controlX,stateX)[1]
//     controlY = control(controlY,stateY)[0]
//     stateY = control(controlY,stateY)[1]    
//   } 
//   if(posX == width -size && posY == height - size){
//     controlX = control(controlX,stateX)[0]
//     stateX = control(controlX,stateX)[1]
//     controlY = control(controlY,stateY)[0]
//     stateY = control(controlY,stateY)[1]
//   }
  
//   if(posX == 0 && posY == height - size){
//     controlX = control(controlX,stateX)[0]
//     stateX = control(controlX,stateX)[1]
//     controlY = control(controlY,stateY)[0]
//     stateY = control(controlY,stateY)[1]
//   }
  
//   if(posX == 0 && posY == 0){
//     controlX = control(controlX,stateX)[0]
//     stateX = control(controlX,stateX)[1]
//     controlY = control(controlY,stateY)[0]
//     stateY = control(controlY,stateY)[1]
//   }
}
function next(f){
  f++
  return f
}


function back(f){
  f--
  return f
}


function move(){
  posX = posX +controlX;
    posY = posY +controlY
}

function control(f,state){
  if( f == 1){
    state = false
  } else
    if( f == -1){
      state = true
    }
  
  if(state == true){
    f++
  } else{
    f--
    }
  return [f,state]
} 

